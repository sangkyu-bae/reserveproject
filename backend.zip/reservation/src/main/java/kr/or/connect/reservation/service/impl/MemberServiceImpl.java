package kr.or.connect.reservation.service.impl;

import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;



import kr.or.connect.reservation.comment.dao.FileInfoDao;

import kr.or.connect.reservation.comment.dao.ReservationUserCommentImgDao;
import kr.or.connect.reservation.comment.dao.ReservationUserCommentsDao;
import kr.or.connect.reservation.comment.dao.userCommentDao;
import kr.or.connect.reservation.comment.dto.FileInfo;
import kr.or.connect.reservation.comment.dto.ReservationUserCommentImg;
import kr.or.connect.reservation.comment.dto.ReservationUserComments;
import kr.or.connect.reservation.comment.dto.userComment;
import kr.or.connect.reservation.login.dao.MemberDao;
import kr.or.connect.reservation.login.dao.MemberRoleDao;
import kr.or.connect.reservation.login.dao.PriceDao;
import kr.or.connect.reservation.login.dao.ProductViewDao;
import kr.or.connect.reservation.login.dao.ReservationInfoDao;
import kr.or.connect.reservation.login.dto.Member;
import kr.or.connect.reservation.login.dto.MemberRole;
import kr.or.connect.reservation.login.dto.Price;
import kr.or.connect.reservation.login.dto.ProductView;
import kr.or.connect.reservation.login.dto.ReservationInfo;
import kr.or.connect.reservation.service.MemberService;
import kr.or.connect.reservation.service.security.UserEntity;
import kr.or.connect.reservation.service.security.UserRoleEntity;

@Service
public class MemberServiceImpl implements MemberService{
	   // 생성자에 위해 주입되는 객체이고, 해당 객체를 초기화할 필요가 이후에 없기 때문에 final로 선언하였다.
    // final로 선언하고 초기화를 안한 필드는 생성자에서 초기화를 해준다.
    private final MemberDao memberDao;
    private final MemberRoleDao memberRoleDao;
    
    // @Service가 붙은 객체는 스프링이 자동으로 Bean으로 생성하는데
    // 기본생성자가 없고 아래와 같이 인자를 받는 생성자만 있을 경우 자동으로 관련된 타입이 Bean으로 있을 경우 주입해서 사용하게 된다.
    public MemberServiceImpl(MemberDao memberDao, MemberRoleDao memberRoleDao) {
        this.memberDao = memberDao;
        this.memberRoleDao = memberRoleDao;
    }
    @Autowired
    PriceDao priceDao;
    @Autowired
    ReservationInfoDao reservationInfoDao;
    @Autowired
    ProductViewDao productViewDao;
    @Autowired
    userCommentDao usercommentDao;
    @Autowired
    FileInfoDao fileInfoDao;
    @Autowired
    ReservationUserCommentImgDao reservationUserCommentImgDao;
    @Autowired
    ReservationUserCommentsDao reservationUserCommentsDao;
    
  
	@Override
	@Transactional
	public UserEntity getUser(String loginUserId) {
		Member member = memberDao.getMemberByemail(loginUserId);
		return new UserEntity(member.getEmail(), member.getPassword());
	}


	@Override
	@Transactional
	public List<UserRoleEntity> getUserRoles(String loginUserId) {
		List<MemberRole>memberRoles =memberRoleDao.getRoleEmail(loginUserId);
		List<UserRoleEntity>list = new ArrayList<>();
		for(MemberRole memberRole :memberRoles) {
			list.add(new UserRoleEntity(loginUserId, memberRole.getRoleName()));
		}
		return list;
	}
	@Override
	@Transactional(readOnly = false)
	public Member addMember(Member member) {
		memberDao.addMember(member);
		Member selectMember =memberDao.getMemberByemail(member.getEmail());
		Long memberId=selectMember.getId();
		
		MemberRole memberRole = new MemberRole();
		
		memberRole.setUserId(memberId);
		memberRole.setRoleName("ROLE_USER");
		memberRoleDao.addMemberRole(memberRole);
		return member;
	}
	@Override
	public Member getMemberByEmail(String loginId) {
		// TODO Auto-generated method stub
		return memberDao.getMemberByemail(loginId);
	}


//	@Override
//	@Transactional(readOnly = false)
//	public Price addPrice(Price price,Long userId, Long productId,
//			Long displayInfoId) {
//		ReservationInfo reservationInfo =new ReservationInfo();
//		
//		
//		return null;
//	}
	@Override
	@Transactional(readOnly = false)
	public ReservationInfo addPrice(Price price, Long userId, Long productId, Long displayInfoId) {
		ReservationInfo reservationInfo = new ReservationInfo();
		
		int i=0;
		Long I=new Long(i);
		
		reservationInfo.setProductId(productId);
		reservationInfo.setDisplayInfoId(displayInfoId);
		reservationInfo.setUserId(userId);
		reservationInfo.setReservationDate(new Date());
		reservationInfo.setCancelFlag(I);
		reservationInfo.setCreateDate(new Date());
		reservationInfo.setModifyDate(new Date());
		Long id =reservationInfoDao.addresevationInfo(reservationInfo);
		reservationInfo.setId(id);
//		Long id =reservationInfoDao.selectMaxId();
		
		price.setReservationInfoId(id);
		Long priceId =priceDao.addreservation(price);
		price.setId(priceId);
		return reservationInfo;
	}

//	@Override
//	@Transactional(readOnly = false)
//	public ReservationInfo addReservationInfo( Long userId, Long productId,
//			Long displayInfoId) {
//		ReservationInfo reservationInfo =new ReservationInfo();
//		int i=0;
//		Long I=new Long(i);
//		
//		reservationInfo.setProductId(productId);
//		reservationInfo.setDisplayInfoId(displayInfoId);
//		reservationInfo.setUserId(userId);
//		reservationInfo.setReservationDate(new Date());
//		reservationInfo.setCancelFlag(I);
//		reservationInfo.setCreateDate(new Date());
//		reservationInfo.setModifyDate(new Date());
//		reservationInfoDao.addresevationInfo(reservationInfo);
////		ReservationInfo reservationInfo2 =reservationInfoDao.selectrReservationId(reservationInfo.getId());
//		
//		return reservationInfo;
//	}
	@Override
	public Long getProductId(Long productPriceId) {
		return priceDao.selectProductId(productPriceId);
	}


	@Override
	public Long getDisplayInfoId(Long productPriceId) {
		return priceDao.selectInfoId(productPriceId);
	}


	@Override
	public ReservationInfo getReservationInfo(Long id) {
		return reservationInfoDao.selectrReservationId(id);
	}


	@Override
	public Long getMaxId() {
		// TODO Auto-generated method stub
		return reservationInfoDao.selectMaxId();
	}


	@Override
	@Transactional
	public List<ProductView> getProductViews(Long userId) {
		List<ProductView>list = productViewDao.selectproductView(userId);
		return list;
	}


	@Override
	@Transactional
	public Long count(Long userId) {
		
		return productViewDao.count(userId);
	}


	@Override
	@Transactional(readOnly = false)
	public int deleteReserve(Long id) {
		int delete=priceDao.delete(id);
		reservationInfoDao.update(id);
		return delete;
	}


//	@Override
//	@Transactional(readOnly = false)
//	public Long addComment(Long reservationInfoId,Double score,String comment,String fileName,String contentType,String saveFileName) {
//		userComment serComment =new userComment();
//		ReservationInfo reservationInfo = reservationInfoDao.getbyreservation(reservationInfoId);
//		serComment.setProductId(reservationInfo.getProductId());
//		serComment.setReservationInfoId(reservationInfoId);
//		serComment.setUserId(reservationInfo.getUserId());
//		serComment.setScore(score);
//		serComment.setComment(comment);
//		serComment.setCreateDate(new Date());
//		serComment.setModifyDate(new Date());
//		Long userCommentId =usercommentDao.insert(serComment);
//		
//		
//		/////
//		int i =0;
//		Long I =new Long (i);
//		FileInfo fileInfo= new FileInfo();
//		fileInfo.setFileName(fileName);
//		fileInfo.setSaveFileName(saveFileName);
//		fileInfo.setContentType(contentType);
//		fileInfo.setDeleteFlag(I);
//		fileInfo.setCreateDate(new Date());
//		fileInfo.setModifyDate(new Date());
//		Long id =fileInfoDao.insertFileInfo(fileInfo);
//		
//		////
//	
//		
//		//////
//		ReservationUserCommentImg reservationUserCommentImg = new ReservationUserCommentImg();
//		reservationUserCommentImg.setReservationInfoId(reservationInfoId);
//		reservationUserCommentImg.setReservationUserCommentId(userCommentId);
//		reservationUserCommentImg.setFileId(id);
//		reservationUserCommentImgDao.insertReserCommentImg(reservationUserCommentImg);
//		
//		return id;
//	}
	@Override
	@Transactional(readOnly = false)
	public Long addComment(Long reservationInfoId,Double score,String comment, MultipartFile file) {
		userComment serComment =new userComment();
		ReservationInfo reservationInfo = reservationInfoDao.getbyreservation(reservationInfoId);
		serComment.setProductId(reservationInfo.getProductId());
		serComment.setReservationInfoId(reservationInfoId);
		serComment.setUserId(reservationInfo.getUserId());
		serComment.setScore(score);
		serComment.setComment(comment);
		serComment.setCreateDate(new Date());
		serComment.setModifyDate(new Date());
		Long userCommentId =usercommentDao.insert(serComment);
		
		
		/////
		String fileName=file.getOriginalFilename();
		String contentType=file.getContentType();
		///파일 이름 중복 회피
		UUID uuid= UUID.randomUUID();
		
		//String saveFileName=contentType+"/"+fileName;
		String saveFileName=uuid.toString()+"_"+fileName;
		int i =0;
		Long I =new Long (i);
		FileInfo fileInfo= new FileInfo();
		fileInfo.setFileName(fileName);
		fileInfo.setSaveFileName(saveFileName);
		fileInfo.setContentType(contentType);
		fileInfo.setDeleteFlag(I);
		fileInfo.setCreateDate(new Date());
		fileInfo.setModifyDate(new Date());
		   try(
	                FileOutputStream fos = new FileOutputStream("c:/tmp/" +saveFileName);
	                InputStream is = file.getInputStream();
	        ){
	        	    int readCount = 0;
	        	    byte[] buffer = new byte[1024];
	            while((readCount = is.read(buffer)) != -1){
	                fos.write(buffer,0,readCount);
	            }
	        }catch(Exception ex){
	            throw new RuntimeException("file Save Error");
	        }
		Long id =fileInfoDao.insertFileInfo(fileInfo);
		
		////
	
		
		//////
		ReservationUserCommentImg reservationUserCommentImg = new ReservationUserCommentImg();
		reservationUserCommentImg.setReservationInfoId(reservationInfoId);
		reservationUserCommentImg.setReservationUserCommentId(userCommentId);
		reservationUserCommentImg.setFileId(id);
		reservationUserCommentImgDao.insertReserCommentImg(reservationUserCommentImg);
		
		return id;
	       
	}
	@Override
	public Long getCommentCount() {
		return usercommentDao.count();
	}


	@Override
	@Transactional
	public List<ReservationUserComments> getComments() {
		List<ReservationUserComments> list = reservationUserCommentsDao.simpleComment(LIMIT);
		for(ReservationUserComments c:list) {
			c.setCommentImages(reservationUserCommentsDao.simpleReservation(c.getReservationInfoId()));
		}
		return list;
	}


	@Override
	@Transactional
	public FileInfo getFileInfo(Long id) {
		return fileInfoDao.getFileInfo(id);
	}

}
