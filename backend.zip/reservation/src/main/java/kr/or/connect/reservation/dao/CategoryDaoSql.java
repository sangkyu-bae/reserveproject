package kr.or.connect.reservation.dao;

public class CategoryDaoSql {
	public static final String SELECT = "select category.id,name,count(*) as count from product,display_info,category where product_id=product.id and category_id=category.id group by category.id";
	public static final String SELECT_PAGING = "SELECT id, name FROM category ORDER BY id DESC ";
	public static final String DELETE_BY_ID = "DELETE FROM category WHERE id = :id";
	public static final String SELECT_COUNT = "SELECT count(*) FROM category";
}
