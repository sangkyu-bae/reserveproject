package kr.or.connect.reservation.comment.dto;

import java.util.List;

import java.util.stream.Collectors;

public class Post {
	private List<ReservationUserComments>comments;

	public List<ReservationUserComments> getComments() {
		return comments;
	}

	public void setComments(List<ReservationUserComments> comments) {
		this.comments = comments;
	}
	
//	public List<ReservationUserCommentImages> comments2(List<ReservationUserComments>comments){
//		return comments.stream()
//				.map(ReservationUserComments::of)
//				.collect(Collectors.toList());
//	}
//	public List<ReservationUserCommentImages> ListDtoToListEntity(List<ReservationUserComments>comments){
//		return comments.stream()
//				.map(ReservationUserComments::toEntity)
//				.collect(Collectors.toList());
//	}
}
