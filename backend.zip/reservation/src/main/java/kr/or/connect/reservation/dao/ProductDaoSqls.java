package kr.or.connect.reservation.dao;

public class ProductDaoSqls {
	public static final String SELECT_PAGING ="select distinct p.id,p.category_id,c.name,d.id as display_info_id, p.description,p.content,\r\n"
			+ "p.event,d.opening_hours,d.place_name,d.place_lot,d.place_street,\r\n"
			+ "d.tel,d.homepage,d.email,d.create_date,d.modify_date,f.file_id\r\n"
			+ "from product p  left outer join category c on p.category_id = c.id \r\n"
			+ "left outer join display_info d on p.id = d.product_id\r\n"
			+ "left outer join product_image f on p.id =f.product_id\r\n"
			+ "where c.id =3 and f.type='ma'\r\n"
			+ "limit :limit";
	public static final String DELETE_BY_ID = "DELETE FROM product WHERE id = :id";
	public static final String SELECT_COUNT = "select count(*)as count \r\n"
			+ "from category,display_info,product \r\n"
			+ "where product_id=product.id and category_id=category.id\r\n"
			+ "and category.id=3";
}
