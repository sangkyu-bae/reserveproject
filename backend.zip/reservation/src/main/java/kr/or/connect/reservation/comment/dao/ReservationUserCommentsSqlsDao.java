package kr.or.connect.reservation.comment.dao;

public class ReservationUserCommentsSqlsDao {
	
	public static final String SELECT_COMMENT="select a.id,a.product_id,a.reservation_info_id,a.score,a.user_id,a.comment,\r\n"
			+ "b.id,b.reservation_info_id,b.reservation_user_comment_id,b.file_id,\r\n"
			+ "c.file_name,c.save_file_name,c.content_type,c.delete_flag,c.create_date,c.modify_date\r\n"
			+ "\r\n"
			+ "from reservation_user_comment a \r\n"
			+ "left outer join reservation_user_comment_image b on a.id = b.reservation_user_comment_id\r\n"
			+ "left outer join file_info c on b.file_id = c.id\r\n"
			+ "\r\n"
			+ "order by a.id desc \r\n"
			+ "limit 0,:limit" ;
	public static final String SELECT_SIMPLE_COMMENT="select id,product_id,reservation_info_id,score,user_id,comment from reservation_user_comment order by id desc limit 0,:limit";
	
	public static final String SELECT_RESERVATION_USER_COMMENT="select b.id,a.reservation_info_id,b.reservation_user_comment_id,b.file_id, \r\n"
			+ "c.file_name,c.save_file_name,c.content_type,c.delete_flag,c.create_date,c.modify_date\r\n"
			+ "\r\n"
			+ "from reservation_user_comment_image b\r\n"
			+ "left outer join reservation_user_comment a on a.id =b.reservation_user_comment_id \r\n"
			+ "left outer join file_info c on c.id=b.file_id\r\n"
			+ "where a.reservation_info_id =:reservationInfoId";
}
