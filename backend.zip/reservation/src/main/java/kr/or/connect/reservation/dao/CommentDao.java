package kr.or.connect.reservation.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.or.connect.reservation.dto.Comment;
import static kr.or.connect.reservation.dao.CommentDaoSqls.*;
@Repository
public class CommentDao {
	NamedParameterJdbcTemplate jdbc;
	RowMapper<Comment>rowMapper = BeanPropertyRowMapper.newInstance(Comment.class);
	
	public CommentDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
	}
	
	
	public List<Comment> reservationSelect(Integer start,Integer limit){
		Map<String, Object> params = new HashMap<>();
		params.put("start", start);
		params.put("limit", limit);
		return jdbc.query(RESERVATIONUSERCOMMENTS, params, rowMapper);
	}
	public int count() {
		return jdbc.queryForObject(COUNT,Collections.emptyMap(), int.class);
	}
}
