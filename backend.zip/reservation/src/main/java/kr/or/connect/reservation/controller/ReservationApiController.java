package kr.or.connect.reservation.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import kr.or.connect.reservation.dto.Category;
import kr.or.connect.reservation.dto.Comment;
import kr.or.connect.reservation.dto.DispalayInfoImages;
import kr.or.connect.reservation.dto.Product;
import kr.or.connect.reservation.dto.ProductImages;
import kr.or.connect.reservation.dto.Promotion;
import kr.or.connect.reservation.dto.Sproduct;
import kr.or.connect.reservation.dto.productPrices;
import kr.or.connect.reservation.login.dto.Price;
//import kr.or.connect.reservation.dto.Product;
import kr.or.connect.reservation.service.ReservationService;

@RestController
@RequestMapping(path="/api")
public class ReservationApiController {
		@Autowired
		ReservationService reservationService;
		
		@ApiOperation(value = "카테고리 목록 구하기")
			@ApiResponses({  // Response Message에 대한 Swagger 설명
		            @ApiResponse(code = 200, message = "OK"),
		            @ApiResponse(code = 500, message = "Exception")
		    })
		
		@GetMapping(path="/categories")	
		public Map<String, Object> items(ModelMap model) {
			List<Category> items =  reservationService.getCategories();
			int size = reservationService.getcount();
			
			Map<String, Object>map=new HashMap<>();
			map.put("size", size);
			map.put("items", items);
			
			return map;
		}
		@DeleteMapping("/{id}")
		public Map<String, String>delete(@PathVariable(name="id")Long id,
				HttpServletRequest request){
			int deleteCount = reservationService.deleteCategory(id);
			return Collections.singletonMap("succes",deleteCount >0? "true":"false" );
		}
		
		@ApiOperation(value = "상품 목록 구하기")
		@ApiResponses({  // Response Message에 대한 Swagger 설명
	            @ApiResponse(code = 200, message = "OK"),
	            @ApiResponse(code = 500, message = "Exception")
	    })
		@GetMapping(path="/displayinfo")
		public Map<String , Object>products(ModelMap model){
			List<Product> products =reservationService.getProducts();
			int totalCount = reservationService.getTotal();
			int productCount = reservationService.LIMIT;
			Map<String, Object>map = new HashMap<>();
			map.put("totalCount", totalCount);
			map.put("productCount", productCount);
			map.put("products", products);
			
			return map;
		}
		@ApiOperation(value = "프로모션 목록 구하기")
		@ApiResponses({  // Response Message에 대한 Swagger 설명
	            @ApiResponse(code = 200, message = "OK"),
	            @ApiResponse(code = 500, message = "Exception")
	    })
		@GetMapping(path="/promotions")
		public Map<String, Object>promotions(){
			List<Promotion>items =reservationService.getPromotions();
			int size =reservationService.get();
			Map<String,Object>map=new HashMap<>();
			map.put("size", size);
			map.put("items", items);
			return map;
		}
		@ApiOperation(value = "카테고리 목록 구하기")
		@ApiResponses({  // Response Message에 대한 Swagger 설명
	            @ApiResponse(code = 200, message = "OK"),
	            @ApiResponse(code = 500, message = "Exception")
	    })
		@GetMapping(path="/displayinfos/{id}")
		public Map<String, Object>Display(@PathVariable(name="id") Long id){
			List<Sproduct>product =reservationService.getSproducts(id);
			List<ProductImages>productImages =reservationService.getProductImages(id);
			List<DispalayInfoImages>dispalayInfoImages=reservationService.getDispalayInfoImages(id);
			List<productPrices>productPrices =reservationService.getProductPrices(id);
			int avgScore = reservationService.getAvg();
			Map<String, Object>map =new HashMap<>();
			map.put("product", product);
			map.put("productImages",productImages );
			map.put("displayInfoImages",dispalayInfoImages);
			map.put("avgScore", avgScore);
			map.put("productPrice", productPrices);
			return map;
		}
		
		@ApiOperation(value = "댓글 목록 구하기")
		@ApiResponses({  // Response Message에 대한 Swagger 설명
	            @ApiResponse(code = 200, message = "OK"),
	            @ApiResponse(code = 500, message = "Exception")
	    })
		
		@GetMapping(path="/displayinfos")
		public Map<String, Object>comment(@RequestParam (name="start",required = false,defaultValue = "0") int start){
			int commentCount = reservationService.Limit;
			int totalCount = reservationService.commentCount();
			List<Comment>comments=reservationService.getComments(start);
			Map<String, Object>map=new HashMap<>();
			map.put("totalCount", totalCount);
			map.put("commentCount", commentCount);
			map.put("comment", comments);
			return map;
		}
		

	
}
