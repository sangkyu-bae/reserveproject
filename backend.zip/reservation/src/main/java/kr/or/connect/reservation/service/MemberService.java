package kr.or.connect.reservation.service;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import kr.or.connect.reservation.comment.dto.FileInfo;
import kr.or.connect.reservation.comment.dto.ReservationUserComments;
import kr.or.connect.reservation.login.dto.Member;
import kr.or.connect.reservation.login.dto.Price;
import kr.or.connect.reservation.login.dto.ProductView;
import kr.or.connect.reservation.login.dto.ReservationInfo;
import kr.or.connect.reservation.service.security.UserDbService;

public interface MemberService extends UserDbService{
	public Member addMember(Member member);
	Member getMemberByEmail(String loginId); 
	public ReservationInfo addPrice(Price price,Long userId,Long productId,Long displayInfoId); 
	//public Price addPrice (Price price ,ReservationInfo info);
	public Long getProductId(Long productPriceId);
	public Long getDisplayInfoId(Long productPriceId);
	ReservationInfo getReservationInfo(Long id);
	public Long getMaxId();
	public List<ProductView> getProductViews(Long userId);
	public Long count(Long userId);
	public int deleteReserve(Long id);
	public Long addComment(Long reservationInfoId,Double score,String comment,MultipartFile file);
	public Long getCommentCount();
	public static final Integer LIMIT=5;
	public List<ReservationUserComments> getComments();
	public FileInfo getFileInfo(Long id);
}
