package kr.or.connect.reservation.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.connect.reservation.dao.CategoryDao;
import kr.or.connect.reservation.dao.CommentDao;
import kr.or.connect.reservation.dao.DisplayDao;
import kr.or.connect.reservation.dao.ProductDao;
import kr.or.connect.reservation.dao.PromotionDao;
import kr.or.connect.reservation.dao.PromotionDaoSql;
import kr.or.connect.reservation.dto.Category;
import kr.or.connect.reservation.dto.Comment;
import kr.or.connect.reservation.dto.DispalayInfoImages;
import kr.or.connect.reservation.dto.Product;
import kr.or.connect.reservation.dto.ProductImages;
import kr.or.connect.reservation.dto.Promotion;
import kr.or.connect.reservation.dto.Sproduct;
import kr.or.connect.reservation.dto.productPrices;
import kr.or.connect.reservation.service.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService{
	@Autowired
	CategoryDao categoryDao;
	@Autowired
	ProductDao productDao;
	@Autowired
	PromotionDao promotionDao; 
	@Autowired 
	DisplayDao displayDao;
	@Autowired
	CommentDao commentDao;
	@Override
	@Transactional
	public List<Category> getCategories() {
		List<Category> list =categoryDao.selectAll();
		return list;
	}

	@Override
	@Transactional(readOnly = false)
	public int deleteCategory(Long id) {
		int delete = categoryDao.Delete(id);
		return delete;
	}

	@Override
	@Transactional(readOnly = false)
	public Category addCategory(Category category) {
		Long id = categoryDao.Insert(category);
		category.setId(id);
		return category;
	}

	@Override
	public int getcount() {
		return categoryDao.Count();
	}

	@Override
	@Transactional
	public List<Product> getProducts() {
		List<Product> list = productDao.selectAll(ReservationService.LIMIT);
		return list;
	}

	@Override
	@Transactional(readOnly = false)
	public int deleteProduct(Long id) {
		int delete = productDao.Delete(id);
		return delete;
	}

	@Override
	@Transactional(readOnly = false)
	public Product addProduct(Product product) {
		Long id = productDao.Insert(product);
		product.setId(id);
		return product;
	}

	@Override
	public int getTotal() {
		return productDao.Count();
	}

	@Override
	@Transactional
	public List<Promotion> getPromotions() {
		List<Promotion>list = promotionDao.selectAll();
		return list;
	}

	@Override
	@Transactional(readOnly = false)
	public int deletePromotion(Long id) {
		int deleteCount = promotionDao.delete(id);
		return deleteCount;
	}

	@Override
	@Transactional(readOnly = false)
	public Promotion addPromotion(Promotion promotion) {
		Long id = promotionDao.insert(promotion);
		promotion.setId(id);
		return promotion;
	}

	@Override
	public int get() {
		// TODO Auto-generated method stub
		return promotionDao.count();
	}

	@Override
	@Transactional
	public List<Sproduct> getSproducts(Long id) {
		List<Sproduct>list=displayDao.displaySelect(id);
		return list;
	}

	@Override
	@Transactional
	public List<ProductImages> getProductImages(Long id) {
		List<ProductImages>list = displayDao.imageSelect(id);
		return list;
	}

	@Override
	@Transactional
	public List<DispalayInfoImages> getDispalayInfoImages(Long id) {
		List<DispalayInfoImages> list =displayDao.dispalayInfoImagesSelect(id);
		return list;
	}

	@Override
	public int getAvg() {
		return displayDao.avg();
	}

	@Override
	@Transactional
	public List<productPrices> getProductPrices(Long id) {
		List<productPrices> list =displayDao.productPrices(id);
		return list;
	}

	@Override
	@Transactional
	public List<Comment> getComments(Integer start) {
		List<Comment>list = commentDao.reservationSelect(start,ReservationService.Limit);
		return list;
	}

	@Override
	public int commentCount() {
		return commentDao.count();
	}


}
