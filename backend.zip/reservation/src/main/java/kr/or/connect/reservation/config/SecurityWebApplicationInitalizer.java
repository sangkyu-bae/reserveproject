package kr.or.connect.reservation.config;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SecurityWebApplicationInitalizer extends AbstractSecurityWebApplicationInitializer {

}
