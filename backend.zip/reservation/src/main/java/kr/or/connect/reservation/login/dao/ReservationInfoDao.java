package kr.or.connect.reservation.login.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import kr.or.connect.reservation.login.dto.Price;
import kr.or.connect.reservation.login.dto.ReservationInfo;


import static kr.or.connect.reservation.login.dao.ReservationInfoDaoSqls.*;
@Repository
public class ReservationInfoDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	private RowMapper<ReservationInfo>rowMapper =BeanPropertyRowMapper.newInstance(ReservationInfo.class);
	
	public ReservationInfoDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
				.withTableName("reservation_info")
				.usingGeneratedKeyColumns("id");
	}
	
	public Long addresevationInfo(ReservationInfo reservationInfo) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(reservationInfo);
		return insertAction.executeAndReturnKey(params).longValue();
	}
	
	public Long selectMaxId() {
		return jdbc.queryForObject(MAX_SELECT, Collections.emptyMap(), Long.class);
	}
	public ReservationInfo selectrReservationId(Long id) {
		Map<String, Object>map =new HashMap<>();
		map.put("id", id);
		return jdbc.queryForObject(SELECT_RESERVATION_INFO_ID, map, rowMapper);
	}
	public int deleteReservation(Long id) {
		Map<String, ?> map =Collections.singletonMap("id", id);
		return jdbc.update(DELETE_RESERVATION, map);
	}
	public int update(Long id) {
		Map<String, ?> map=Collections.singletonMap("id", id);
		return jdbc.update(UPDATE_RESERVATION, map);
	}
	public ReservationInfo getbyreservation(Long id) {
		Map<String, Object>map = new HashMap<>();
		map.put("id", id);
		return jdbc.queryForObject(GET_BY_RESERVATION, map, rowMapper);
	}
}
