package kr.or.connect.reservation.login.dao;

public class ReservationInfoDaoSqls {

	
	public static final String MAX_SELECT ="select max(id)as id from reservation_info";
	public static final String SELECT_RESERVATION_INFO_ID=" select id, product_id,display_info_id,user_id,reservation_date,cancel_flag,create_date,modify_date from reservation_info where id=:id";
	public static final String DELETE_RESERVATION="delete from reservation_info where id =:id";
	public static final String UPDATE_RESERVATION="update reservation_info\r\n"
			+ "set cancel_flag=1\r\n"
			+ "where id=:id";
	public static final String GET_BY_RESERVATION="select * from reservation_info where id =:id";
	
}