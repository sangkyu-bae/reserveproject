package kr.or.connect.reservation.dao;

public class PromotionDaoSql {
	public static final String SELECT="select a.id,a.product_id,b.category_id,c.name as category_name\r\n"
			+ ",b.description,d.file_id\r\n"
			+ "\r\n"
			+ "from promotion a left outer join product b on a.product_id=b.id\r\n"
			+ "left outer join category c on b.category_id = c.id\r\n"
			+ "left outer join product_image d on b.id = d.product_id\r\n"
			+ "where d.type='ma'";
	public static final String DELETE_BY_ID="DELETE FROM promotion WHERE id = :id";
	public static final String SELECT_COUNT="\r\n"
			+ "select count(*)as count \r\n"
			+ "from promotion a, product b, category c, product_image d\r\n"
			+ "where a.product_id=b.id and b.category_id=c.id \r\n"
			+ "and b.id=d.product_id\r\n"
			+ "and d.type='ma'";
}
