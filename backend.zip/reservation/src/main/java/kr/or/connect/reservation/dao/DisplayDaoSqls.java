package kr.or.connect.reservation.dao;

public class DisplayDaoSqls {
	public static final String PRODUCT="\r\n"
			+ "select p.id,p.category_id,c.name,d.id as display_info_id, p.description,p.content,\r\n"
			+ "p.event,d.opening_hours,d.place_name,d.place_lot,d.place_street,\r\n"
			+ "d.tel,d.homepage,d.email,d.create_date,d.modify_date,f.file_id\r\n"
			+ "from product p  left outer join category c on p.category_id = c.id \r\n"
			+ "left outer join display_info d on p.id = d.product_id\r\n"
			+ "left outer join product_image f on p.id =f.product_id\r\n"
			+ "where f.type='ma' and  p.id = :id";
	public static final String PRODUCTIMAGES="select a.product_id,a.id as product_image_id,a.type,\r\n"
			+ "a.file_id as file_info_id,b.file_name, b.save_file_name,\r\n"
			+ "b.content_type,b.delete_flag,b.create_date,b.modify_date\r\n"
			+ "\r\n"
			+ "from product_image a left outer join file_info b on a.file_id=b.id\r\n"
			+ "left outer join display_info c on a.product_id = c.product_id\r\n"
			+ "where c.id= :productId and a.type='ma'";
			
	public static final String DISPLAYINFOIMAGES ="select a.id,a.display_info_id,a.file_id,\r\n"
			+ "b.file_name,b.save_file_name,b.content_type,b.delete_flag,\r\n"
			+ "b.create_date,b.modify_date\r\n"
			+ "\r\n"
			+ "from display_info_image a left outer join file_info b on a.file_id=b.id\r\n"
			+ "where a.display_info_id = :displayInfoId";
	public static final String AVRERGE="select avg(score) as avg_score from reservation_user_comment";
	
	public static final String PRODUCTPRICES="select * from product_price where product_id=:productId order by id  desc";
}
