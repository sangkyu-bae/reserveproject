package kr.or.connect.reservation.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import org.springframework.stereotype.Repository;
import static kr.or.connect.reservation.dao.DisplayDaoSqls.*;

import kr.or.connect.reservation.dto.ProductImages;
import kr.or.connect.reservation.dto.Sproduct;
import kr.or.connect.reservation.dto.productPrices;
import kr.or.connect.reservation.dto.DispalayInfoImages;

@Repository
public class DisplayDao {
	private NamedParameterJdbcTemplate jdbc;
	private RowMapper<Sproduct>rowMapper = BeanPropertyRowMapper.newInstance(Sproduct.class);
	private RowMapper<ProductImages>rowMapper2 =BeanPropertyRowMapper.newInstance(ProductImages.class);
	private RowMapper<DispalayInfoImages>rowMapper3= BeanPropertyRowMapper.newInstance(DispalayInfoImages.class);
	private RowMapper<productPrices>rowMapper4=BeanPropertyRowMapper.newInstance(productPrices.class);
	public DisplayDao(DataSource dataSource) {
		this.jdbc =new NamedParameterJdbcTemplate(dataSource);
	}
	
	public List<Sproduct> displaySelect(Long id) {
		Map<String, Long>params=new HashMap<>();
		params.put("id", id);
		return jdbc.query(PRODUCT,params,rowMapper );
	}
	public List<ProductImages>imageSelect(Long id){
		Map<String, Long>params=new HashMap<>();
		params.put("productId", id);
		return jdbc.query(PRODUCTIMAGES, params, rowMapper2);
	}
	public List<DispalayInfoImages>dispalayInfoImagesSelect(Long id){
		Map<String, Long>params =new HashMap<>();
		params.put("displayInfoId", id);
		return jdbc.query(DISPLAYINFOIMAGES, params, rowMapper3);
	}
	public int avg() {
		return jdbc.queryForObject(AVRERGE, Collections.emptyMap(), int.class);
	}
	public List<productPrices>productPrices(Long id){
		Map<String, Object>params = new HashMap<>();
		params.put("productId", id);
		return jdbc.query(PRODUCTPRICES, params, rowMapper4);
	}
	
}
