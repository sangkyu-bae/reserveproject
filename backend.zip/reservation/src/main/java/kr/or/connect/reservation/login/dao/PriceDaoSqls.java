package kr.or.connect.reservation.login.dao;

public class PriceDaoSqls {
	public static final String SELECT_RE_PR=" select * from reservation_info_price where id =:id";
	
	public static final String SELECT_PRODUCT_ID = "\r\n"
			+ "select distinct b.product_id\r\n"
			+ "from reservation_info_price a\r\n"
			+ "left outer join product_price b on a.product_price_id=b.id\r\n"
			+ "where a.product_price_id = :productPriceId";
			
	public static final String SELECT_DISPLAY_INFO_ID="select distinct d.id as display_info_id\r\n"
			+ "from reservation_info_price a\r\n"
			+ "\r\n"
			+ "left outer join product_price b on a.product_price_id=b.id\r\n"
			+ "left outer join product c on b.product_id=c.id\r\n"
			+ "left outer join display_info d on c.id=d.product_id\r\n"
			+ "where a.product_price_id =:productPriceId";
	public static final String DELETE_PRICE="delete from reservation_info_price where reservation_info_id =:reservationInfoId";
}
