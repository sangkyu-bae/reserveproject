package kr.or.connect.reservation.controller;

import java.io.File;
import java.io.FileInputStream;


import java.io.OutputStream;

import java.security.Principal;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import kr.or.connect.reservation.comment.dto.FileInfo;
import kr.or.connect.reservation.comment.dto.ReservationUserComments;
import kr.or.connect.reservation.login.dto.Member;
import kr.or.connect.reservation.login.dto.Price;
import kr.or.connect.reservation.login.dto.ProductView;
import kr.or.connect.reservation.login.dto.ReservationInfo;
import kr.or.connect.reservation.service.MemberService;

@RestController
@RequestMapping(path="/api")
public class MemberContorollerApi {
	@Autowired
	MemberService memberService;
	

	@ApiOperation(value = "예약 등록 하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@PostMapping(path="/reservationInfos")
	public Map<String, Object> reservationInfo(@RequestBody Price prices,
			Principal principal){
		String loginId=principal.getName();
		Member member =memberService.getMemberByEmail(loginId);
		Long userId=member.getId();
		Long productId=memberService.getProductId(prices.getProductPriceId());
		Long displayInfoId=memberService.getDisplayInfoId(prices.getProductPriceId());
		
		ReservationInfo resultPrice =memberService.addPrice(prices,userId,productId,displayInfoId);
		Map<String, Object> map =new HashMap<>();
		map.put("reservationInfo",resultPrice );
		map.put("prices", prices);
		return map;
	}
	
	
	@ApiOperation(value = "주문 정보 구하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@GetMapping(path="/reservationInfos")
	public Map<String, Object>getReservation(Principal principal){
		String loginId = principal.getName();
		Member member =memberService.getMemberByEmail(loginId);
		Long userId=member.getId();
		Long size = memberService.count(userId);
		List<ProductView> item= memberService.getProductViews(userId);
		Map<String, Object>map =new HashMap<>();
		map.put("size", size);
		map.put("item", item);
		return map;
	}
	
	@ApiOperation(value = "예약 취소 하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@PutMapping(path="/reservations")
	public Map<String,Object>deleteReser(@RequestBody ReservationInfo reservationInfo ){
		Long id =reservationInfo.getId();
		int deleteCount =memberService.deleteReserve(id);
		return Collections.singletonMap("result",deleteCount >0? "success":"false" );
	}

	@ApiOperation(value = "댓글 등록 하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@PostMapping(path="/comments")
	public Map<String, Object>resgister(@RequestParam (name="reservationInfoId")Long reservationInfoId,
			@RequestParam (name="score")Double score,
			@RequestParam (name="comment") String comment,
			@RequestParam("multipartfile")MultipartFile file,
			Principal principal
				){
		
//		String loginId =principal.getName();
//		Member member = memberService.getMemberByEmail(loginId);
//		Long userId= member.getId();
//		//파일 전달하는 구조
//		String fileName=file.getOriginalFilename();
//		String contentType=file.getContentType();
//		///파일 이름 중복 회피
//		UUID uuid= UUID.randomUUID();
//		
//		//String saveFileName=contentType+"/"+fileName;
//		String saveFileName=uuid.toString()+"_"+fileName;
//		/////
//		   try(
//	                // 맥일 경우 
//	                //FileOutputStream fos = new FileOutputStream("/tmp/" + file.getOriginalFilename());
//	                // 윈도우일 경우
//	                FileOutputStream fos = new FileOutputStream("c:/tmp/" +saveFileName);
//	                InputStream is = file.getInputStream();
//	        ){
//	        	    int readCount = 0;
//	        	    byte[] buffer = new byte[1024];
//	            while((readCount = is.read(buffer)) != -1){
//	                fos.write(buffer,0,readCount);
//	            }
//	        }catch(Exception ex){
//	            throw new RuntimeException("file Save Error");
//	        }
//		   
//		   //////
//		   /////productId 받아오기위한 객체 생성후 get으로 받아오기
//		ReservationInfo reservationInfo = memberService.getReservationInfo(reservationInfoId);
//		Long productId= reservationInfo.getProductId();
//		
//		Long id=memberService.addComment(reservationInfoId, score, comment,fileName,contentType,saveFileName);
//		Map<String, Object>map = new HashMap<>();
//		/////성공인지 아닌지 판단
//		String result = "";//빈 문자열 생성
//		if(id>0) {
//			result="success";
//		}else {
//			result="flase";
//		}////id 값이 0보다크면 성공 작으면 실패 반환
//		
//		map.put("result", result);
//		map.put("productId", productId);
//		return map;
//////////////////////////////////////////////////
		   
		   //////
		   /////productId 받아오기위한 객체 생성후 get으로 받아오기
		ReservationInfo reservationInfo = memberService.getReservationInfo(reservationInfoId);
		Long productId= reservationInfo.getProductId();
		
		Long id=memberService.addComment(reservationInfoId, score, comment,file);
		Map<String, Object>map = new HashMap<>();
		/////성공인지 아닌지 판단
		String result = "";//빈 문자열 생성
		if(id>0) {
			result="success";
		}else {
			result="flase";
		}////id 값이 0보다크면 성공 작으면 실패 반환
		
		map.put("result", result);
		map.put("productId", productId);
		return map;
	}
	@ApiOperation(value = "댓글 목록 구하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@GetMapping(path="/comments")
	public Map<String, Object>getComment(){
		Long totalCount=memberService.getCommentCount();
		Integer commentCount=memberService.LIMIT;
		List<ReservationUserComments> list=memberService.getComments();
	
		Map<String, Object>map = new HashMap<>();
	
		map.put("totalCount", totalCount);
		map.put("commentCount", commentCount);
		map.put("list", list);
	
		return map;
	}
	
	@ApiOperation(value = "이미지 다운로드하기")
	@ApiResponses({  // Response Message에 대한 Swagger 설명
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 500, message = "Exception")
    })
	@GetMapping(path="/files/{fileId}")
	public void downloadFile(@PathVariable(name="fileId")Long fileId,
			HttpServletResponse response){
		FileInfo fileInfo = memberService.getFileInfo(fileId);
		String fileName=fileInfo.getFileName();
		String saveFileName ="c:/tmp/"+fileInfo.getSaveFileName();
		String contentType=fileInfo.getContentType();
		
		File file = new File(saveFileName);
	
		Long fileLength=file.length();
		
			response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\";");
	        response.setHeader("Content-Transfer-Encoding", "binary");
	        response.setHeader("Content-Type", contentType);
	        response.setHeader("Content-Length", "" + fileLength);
	        response.setHeader("Pragma", "no-cache;");
	        response.setHeader("Expires", "-1;");
	        
	        try(
	                FileInputStream fis = new FileInputStream(saveFileName);
	                OutputStream out = response.getOutputStream();
	        ){
	        	    int readCount = 0;
	        	    byte[] buffer = new byte[1024];
	            while((readCount = fis.read(buffer)) != -1){
	            		out.write(buffer,0,readCount);
	            }
	        }catch(Exception ex){
	            throw new RuntimeException("file Save Error");
	        }
	}
}
