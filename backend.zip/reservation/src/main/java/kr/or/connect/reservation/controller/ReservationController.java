package kr.or.connect.reservation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;

import kr.or.connect.reservation.dto.Category;
import kr.or.connect.reservation.service.ReservationService;

@Controller
public class ReservationController {
	@Autowired 
	ReservationService reservationService;
	@GetMapping(path="/index")
	public String index() {
		return "redirect:/list";
	}
	
	@GetMapping(path = "/list")
	public String list(ModelMap model) {
		List<Category> list = reservationService.getCategories();
		
		int count =reservationService.getcount();
		
		model.addAttribute("list", list);
		model.addAttribute("count", count);
		return "list";
	}
}
