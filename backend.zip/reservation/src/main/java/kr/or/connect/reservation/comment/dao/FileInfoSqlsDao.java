package kr.or.connect.reservation.comment.dao;

public class FileInfoSqlsDao {
	public static final String SELECT_FILE_INFO="select *from file_info where id=:id";
	
}
