package kr.or.connect.reservation.dao;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.google.protobuf.Int32Value;

import kr.or.connect.reservation.config.ApplicationConfig;
import kr.or.connect.reservation.dto.Category;
import kr.or.connect.reservation.dto.Product;
import kr.or.connect.reservation.dto.Sproduct;

public class CategoryDaoTest {
	public static void main(String[] args) {
		ApplicationContext ac= new AnnotationConfigApplicationContext(ApplicationConfig.class);
		CategoryDao categoryDao = ac.getBean(CategoryDao.class);
		ProductDao productDao = ac.getBean(ProductDao.class);
		DisplayDao displayDao = ac.getBean(DisplayDao.class);
		List<Category> list = categoryDao.selectAll();
		
		for(Category cate : list) {
			System.out.println(cate);
		}
		
//		List<Product> pro = productDao.selectAll();
//		
//		for (Product p : pro) {
//			System.out.println(p);
//		}
		
		/*Sproduct sproduct =new Sproduct();
		long a =1;
		sproduct.setId(a);
		List<Sproduct>sp = displayDao.displaySelect();
		for(Sproduct s : sp) {
			System.out.println(s);
		}*/
		
	
	}
}
