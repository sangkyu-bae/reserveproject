package kr.or.connect.reservation.service;

import java.util.List;

import org.springframework.stereotype.Service;

import kr.or.connect.reservation.dto.Category;
import kr.or.connect.reservation.dto.Comment;
import kr.or.connect.reservation.dto.DispalayInfoImages;
import kr.or.connect.reservation.dto.Product;
import kr.or.connect.reservation.dto.ProductImages;
import kr.or.connect.reservation.dto.Promotion;
import kr.or.connect.reservation.dto.Sproduct;
import kr.or.connect.reservation.dto.productPrices;


public interface ReservationService {
	public List<Category> getCategories();
	public int deleteCategory(Long id);
	public Category addCategory(Category category);
	public int getcount();
	////////////
	public static Integer LIMIT=4;
	public List<Product> getProducts();
	public int deleteProduct(Long id);
	public Product addProduct(Product product);
	public int getTotal();
	////////////////////////////
	public List<Promotion> getPromotions();
	public int deletePromotion(Long id);
	public Promotion addPromotion(Promotion promotion);
	public int get();
	//////////////////
	public List<Sproduct> getSproducts(Long id);
	public List<ProductImages> getProductImages(Long id);
	public List<DispalayInfoImages> getDispalayInfoImages(Long id);
	public int getAvg();
	public List<productPrices> getProductPrices(Long id);
	public static Integer Limit=5;
 	public List<Comment> getComments(Integer start);
 	public int commentCount();
}
