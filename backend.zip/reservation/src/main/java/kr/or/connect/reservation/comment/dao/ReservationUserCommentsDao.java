package kr.or.connect.reservation.comment.dao;



import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import kr.or.connect.reservation.comment.dto.Post;
import kr.or.connect.reservation.comment.dto.ReservationUserCommentImages;
import kr.or.connect.reservation.comment.dto.ReservationUserComments;
import static kr.or.connect.reservation.comment.dao.ReservationUserCommentsSqlsDao.*;
@Repository
public class ReservationUserCommentsDao {
	private NamedParameterJdbcTemplate jdbc;
	private RowMapper<ReservationUserComments>rowMapper=BeanPropertyRowMapper.newInstance(ReservationUserComments.class);
	
	///
	private RowMapper<Post>rowMapper2= BeanPropertyRowMapper.newInstance(Post.class);
	///
	
	private RowMapper<ReservationUserCommentImages>rowMapper3= BeanPropertyRowMapper.newInstance(ReservationUserCommentImages.class);
	public ReservationUserCommentsDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
	}
	
	public List<ReservationUserComments>simpleComment(Integer limit){
		Map<String, Object>map =new HashMap<>();
		map.put("limit", limit);
		return jdbc.query(SELECT_SIMPLE_COMMENT, map, rowMapper);
	}
	
	public List<ReservationUserCommentImages>simpleReservation(Long reservationInfoId){
		Map<String, Object>map= new HashMap<>();
		map.put("reservationInfoId", reservationInfoId);
		return jdbc.query(SELECT_RESERVATION_USER_COMMENT, map, rowMapper3);
	}
	
	////
	public List<Post>simple(Integer limit){
		Map<String, Object>map= new HashMap<>();
		map.put("limit", limit);
		return jdbc.query(SELECT_COMMENT, map, rowMapper2);
	}
	
	//
}
