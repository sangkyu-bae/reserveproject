package kr.or.connect.reservation.login.dao;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import kr.or.connect.reservation.login.dto.Price;
import static kr.or.connect.reservation.login.dao.PriceDaoSqls.*;
@Repository
public class PriceDao {
	private NamedParameterJdbcTemplate jdbc;
	private RowMapper<Price>rowMapper =BeanPropertyRowMapper.newInstance(Price.class);
	private SimpleJdbcInsert InsertAction;
	
	public PriceDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
		this.InsertAction = new SimpleJdbcInsert(dataSource)
				.withTableName("reservation_info_price")
				.usingGeneratedKeyColumns("id");
	}
	
	public Long addreservation(Price price) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(price);
		return InsertAction.executeAndReturnKey(params).longValue();
	}
	
	public Long selectProductId(Long productPriceId) {
		Map<String, Long >params =new HashMap<>();
		params.put("productPriceId", productPriceId);
		return jdbc.queryForObject(SELECT_PRODUCT_ID, params,Long.class );
	}
	
	public Long selectInfoId(Long productPriceId) {
		Map<String, Long> params=new HashMap<>();
		params.put("productPriceId", productPriceId);
		return jdbc.queryForObject(SELECT_DISPLAY_INFO_ID, params, Long.class);
	}
	public Price getPrice(Long id) {
		Map<String, Object>map =new HashMap<>();
		map.put("id", id);
		return jdbc.queryForObject(SELECT_RE_PR, map, rowMapper);
	}
	public int delete(Long reservationInfoId) {
		Map<String, ?>map =Collections.singletonMap("reservationInfoId", reservationInfoId);
		return jdbc.update(DELETE_PRICE, map);
		
	}
	
	
}
