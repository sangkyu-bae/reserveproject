package kr.or.connect.reservation.comment.dao;

import java.util.HashMap;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import kr.or.connect.reservation.comment.dto.FileInfo;
import static kr.or.connect.reservation.comment.dao.FileInfoSqlsDao.*;
@Repository
public class FileInfoDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	private RowMapper<FileInfo>rowMapper=BeanPropertyRowMapper.newInstance(FileInfo.class);
	public FileInfoDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
				.withTableName("file_info")
				.usingGeneratedKeyColumns("id");
	}
	public Long insertFileInfo(FileInfo fileInfo) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(fileInfo);
		return insertAction.executeAndReturnKey(params).longValue();
	}
	
	public FileInfo getFileInfo(Long id) {
		Map<String , Object>map = new HashMap<>();
		map.put("id", id);
		return jdbc.queryForObject(SELECT_FILE_INFO, map,rowMapper);
	}
}
