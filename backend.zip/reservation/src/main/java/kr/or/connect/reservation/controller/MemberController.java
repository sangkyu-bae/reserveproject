package kr.or.connect.reservation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import kr.or.connect.reservation.login.dto.Member;
import kr.or.connect.reservation.service.MemberService;

@Controller
@RequestMapping(path="/members")
public class MemberController {
	  private final MemberService memberService;
	  private final PasswordEncoder passwordEncoder;
	  public MemberController(MemberService memberService, PasswordEncoder passwordEncoder) {
		  this.memberService =	memberService;
		  this.passwordEncoder =passwordEncoder;
	  }
//	@Autowired
//	MemberService memberService;
//	@Autowired
//	PasswordEncoder passwordEncoder;
	@GetMapping("/loginform")
	public String loginform() {
		return "members/loginform";
	}
	@RequestMapping("/loginerror")
	public String loginerror(@RequestParam ("login_error")String loginError) {
		return "members/loginerror";
	}
	@GetMapping("/joinform")
	public String joinform() {
		return "members/joinform";
	}
	@PostMapping("/join")
	public String join(@ModelAttribute Member member) {
		member.setPassword(passwordEncoder.encode(member.getPassword()));
		memberService.addMember(member);
		return "redirect:/list";
	}

}
