package kr.or.connect.reservation.comment.dao;

public class userCommentSqlsDao {
	public static final String SELECT_COMMENT_ALL="select id,product_id,reservation_info_id,score,user_id,comment from reservation_user_comment order by id desc limit :start, :limit";
	public static final String COUNT_COMMENT="select count(*)as total_count from reservation_user_comment";
}
