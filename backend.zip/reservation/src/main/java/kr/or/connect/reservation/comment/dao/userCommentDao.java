package kr.or.connect.reservation.comment.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import static kr.or.connect.reservation.comment.dao.userCommentSqlsDao.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import kr.or.connect.reservation.comment.dto.userComment;
@Repository
public class userCommentDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	private RowMapper<userComment>rowMapper = BeanPropertyRowMapper.newInstance(userComment.class);
	
	public userCommentDao(DataSource dataSource) {
		this.jdbc=new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
				.withTableName("reservation_user_comment")
				.usingGeneratedKeyColumns("id");
	}
	
	public Long insert(userComment comment) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(comment);
		return insertAction.executeAndReturnKey(params).longValue();
	}
	public Long count() {
		return jdbc.queryForObject(COUNT_COMMENT, Collections.emptyMap(), Long.class);
	}
//	public List<userComment>comments(Integer start,Integer limit){
//		Map<String, Integer>map = new HashMap<>();
//		map.put("start",start);
//		map.put("limit", limit);
//		
//		return jdbc.query(SELECT_COMMENT_ALL, map, rowMapper);
//	}
}
