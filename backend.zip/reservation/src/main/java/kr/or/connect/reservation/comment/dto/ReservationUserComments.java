package kr.or.connect.reservation.comment.dto;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class ReservationUserComments {
	
	private Long id;
	private Long productId;
	private Long reservationInfoId;
	private Double score;
	private	Long userId;
	private String comment;
	private List<ReservationUserCommentImages>commentImages;
	
	public List<ReservationUserCommentImages> getCommentImages() {
		return commentImages;
	}
	public void setCommentImages(List<ReservationUserCommentImages> commentImages) {
		this.commentImages = commentImages;
	}
	//객체선언
//	private ReservationUserCommentImages commentImages2;
//	
//	매핑 매서드
//	public ReservationUserCommentImages toEntity() {
//		return new ReservationUserCommentImages(commentImages2);
//	}
//	
//	
//	
//	리스트선언
//	private List<ReservationUserCommentImages>commentImages;
//	리스트매핑 매서드
//	public List<ReservationUserCommentImages> listDtoToList(List<ReservationUserComments>comments){
//		return comments.stream()
//				.map(ReservationUserComments::toEntity)
//				.collect(Collectors.toList());
//	}
//
//	public List<ReservationUserCommentImages> getCommentImages() {
//		return commentImages;
//	}
//	public void setCommentImages(List<ReservationUserCommentImages> commentImages) {
//		this.commentImages = commentImages;
//	}
//	
	
	
			
//	
//	private Long ids;
//	private Long reservationInfoIds;
//	private Long reservationUserCommentId;
//	private Long filedId;
//	private String fileName;
//	private String saveFileName;
//	private String contentType;
//	private Long deleteFlag;
//	private Date createDate;
//	private Date modifyDate;
//	
//	ReservationUserCommentImages comments ;
//	
//	private List<ReservationUserCommentImages>commentImages;
//
//	public List<ReservationUserCommentImages> getCommentImages() {
//		return commentImages;
//	}
//	
//	
//	public ReservationUserCommentImages of() {
//		return new ReservationUserCommentImages(ids,reservationInfoIds,reservationUserCommentId,filedId,fileName,saveFileName
//				,contentType,deleteFlag,createDate,modifyDate);
//		
//	}
	
//	public static ReservationUserComments of(List<ReservationUserCommentImages>commentImages) {
//		
//	}
//	
//	public List<ReservationUserCommentImages> ListDtoToListEntity(List<ReservationUserComments>comments){
//	return comments.stream()
//			.map(ReservationUserComments::toEntity)
//			.collect(Collectors.toList());
//}
	
	

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Long getReservationInfoId() {
		return reservationInfoId;
	}
	public void setReservationInfoId(Long reservationInfoId) {
		this.reservationInfoId = reservationInfoId;
	}
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

	
}
