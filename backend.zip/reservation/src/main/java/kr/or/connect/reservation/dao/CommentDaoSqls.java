package kr.or.connect.reservation.dao;

public class CommentDaoSqls {
	public static final String RESERVATIONUSERCOMMENTS ="select a.id,a.product_id,a.reservation_info_id,a.score,\r\n"
			+ "b.email as reservation_email, a.comment,a.create_date,a.modify_date\r\n"
			+ "\r\n"
			+ "from reservation_user_comment a left outer join user b on a.user_id=b.id\r\n"
			+ "\r\n"
			+ "order by a.id desc\r\n"
			+ "limit :start,:limit";
	public static final String COUNT = "select count(*) from reservation_user_comment";
}
