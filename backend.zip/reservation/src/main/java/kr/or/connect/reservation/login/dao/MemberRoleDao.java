package kr.or.connect.reservation.login.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import static kr.or.connect.reservation.login.dao.MemberRoleDaoSqls.*;
import kr.or.connect.reservation.login.dto.MemberRole;

@Repository
public class MemberRoleDao {
	private NamedParameterJdbcTemplate jdbc;
	private SimpleJdbcInsert insertAction;
	private RowMapper<MemberRole>rowMapper = BeanPropertyRowMapper.newInstance(MemberRole.class);
	
	public MemberRoleDao(DataSource dataSource) {
		this.jdbc = new NamedParameterJdbcTemplate(dataSource);
		this.insertAction = new SimpleJdbcInsert(dataSource)
				.withTableName("user_role")
				.usingGeneratedKeyColumns("id");
	}
	
	public List<MemberRole> getRoleEmail(String email){
		Map<String, Object>map=new HashMap<>();
		map.put("email", email);
		return jdbc.query(SELECT_ALL_BY_EMAIL, map, rowMapper);
	}
	public Long addMemberRole(MemberRole memberRole) {
		SqlParameterSource params = new BeanPropertySqlParameterSource(memberRole);
		return insertAction.executeAndReturnKey(params).longValue();
	}
}
