package kr.or.connect.reservation.login.dao;

public class ProductViewDaoSqls {
	public static final String SELECT_PRODUCT_VIEW ="select c.reservation_info_id as id,a.product_id,a.display_info_id,a.cancel_flag,\r\n"
			+ "b.description as product_description,b.content as product_content,\r\n"
			+ "a.user_id,\r\n"
			+ "sum(c.count*d.price) as sum_price,\r\n"
			+ "a.reservation_date,a.create_date,a.modify_date\r\n"
			+ "\r\n"
			+ " from reservation_info_price c\r\n"
			+ "left outer join product_price d on c.product_price_id =d. id\r\n"
			+ "left outer join reservation_info a on a.id = c.reservation_info_id\r\n"
			+ "left outer join product b on b.id = a.product_id\r\n"
			+ "where a.user_id =:userId\r\n"
			+ "group by c.reservation_info_id";
	
	public static final String SELECT_COUNT="select count(*) \r\n"
			+ "from reservation_info\r\n"
			+ "where user_id =:userId";
}
